$body = @{
    comment = "shop oi gia bao nhieu?"
    user = "viewer_001"
} | ConvertTo-Json -Depth 5

Invoke-RestMethod `
  -Uri "http://127.0.0.1:5678/webhook/ai-livestream-comment" `
  -Method POST `
  -ContentType "application/json" `
  -Body ([System.Text.Encoding]::UTF8.GetBytes($body))
